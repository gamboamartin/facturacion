<?php

namespace gamboamartin\facturacion\models;

use config\generales;
use gamboamartin\cat_sat\models\cat_sat_regimen_fiscal;
use gamboamartin\errores\errores;
use gamboamartin\facturacion\controllers\pdf;
use gamboamartin\organigrama\models\org_logo;
use NumberFormatter;
use PDO;
use setasign\Fpdi\Fpdi;
use stdClass;
use Throwable;

class _pdf
{
    private errores $error;
    private array $cfg = []; // nuevo
    private bool $cambios_titulo_pdf = false;
    private bool $leyenda_factura_pdf = false; 


    public function __construct()
    {
        $generales_pdf = new generales();
        if (isset($generales_pdf->cambios_titulo_pdf)) {
            $this->cambios_titulo_pdf = $generales_pdf->cambios_titulo_pdf;
        }
        if (isset($generales_pdf->leyenda_factura_pdf)) {
        $this->leyenda_factura_pdf = $generales_pdf->leyenda_factura_pdf;
        }
        $this->error = new errores();
    }


    private function numero_a_letras(float $numero, string $moneda = 'pesos', string $centavos = 'centavos'): string
    {
        $unidades = ['', 'uno', 'dos', 'tres', 'cuatro', 'cinco', 'seis', 'siete', 'ocho', 'nueve'];
        $decenas = ['', 'diez', 'veinte', 'treinta', 'cuarenta', 'cincuenta', 'sesenta', 'setenta', 'ochenta', 'noventa'];
        $especiales = [11 => 'once', 12 => 'doce', 13 => 'trece', 14 => 'catorce', 15 => 'quince',
            16 => 'dieciséis', 17 => 'diecisiete', 18 => 'dieciocho', 19 => 'diecinueve'];
        $centenas = ['', 'cien', 'doscientos', 'trescientos', 'cuatrocientos', 'quinientos',
            'seiscientos', 'setecientos', 'ochocientos', 'novecientos'];

        if ($numero < 0) {
            return 'menos ' . $this->numero_a_letras(abs($numero), $moneda, $centavos);
        }

        $parte_entera = (int)$numero;
        $parte_decimal = round(($numero - $parte_entera) * 100);

        $texto = $this->convertir_mayores($parte_entera, $unidades, $decenas, $especiales, $centenas);

        if ($texto == '') {
            $texto = 'cero';
        }

        $resultado = ucfirst($texto) . " $moneda";

        if ($parte_decimal > 0) {
            $resultado .= " con " . $this->convertir_mayores($parte_decimal, $unidades, $decenas, $especiales, $centenas) . " $centavos";
        }

        return $resultado;
    }

    private function convertir_mayores($numero, $unidades, $decenas, $especiales, $centenas)
    {
        if ($numero == 0) return '';

        if ($numero < 1000) {
            return $this->convertir_cientos($numero, $unidades, $decenas, $especiales, $centenas);
        }

        if ($numero < 1000000) {
            $miles = (int)($numero / 1000);
            $resto = $numero % 1000;
            $texto_miles = ($miles == 1) ? 'mil' : $this->convertir_cientos($miles, $unidades, $decenas, $especiales, $centenas) . ' mil';
            return trim($texto_miles . ' ' . $this->convertir_cientos($resto, $unidades, $decenas, $especiales, $centenas));
        }

        if ($numero < 1000000000) {
            $millones = (int)($numero / 1000000);
            $resto = $numero % 1000000;
            $texto_millones = ($millones == 1) ? 'un millón' : $this->convertir_cientos($millones, $unidades, $decenas, $especiales, $centenas) . ' millones';
            return trim($texto_millones . ' ' . $this->convertir_mayores($resto, $unidades, $decenas, $especiales, $centenas));
        }

        return 'Número demasiado grande';
    }

    function convertir_cientos($numero, $unidades, $decenas, $especiales, $centenas)
    {
        if ($numero == 0) return '';

        if ($numero < 10) {
            return $unidades[$numero];
        }

        if ($numero < 20) {
            return $especiales[$numero] ?? '';
        }

        if ($numero < 100) {
            $unidad = $numero % 10;
            return $decenas[(int)($numero / 10)] . ($unidad ? ' y ' . $unidades[$unidad] : '');
        }

        if ($numero < 1000) {
            $centena = (int)($numero / 100);
            $resto = $numero % 100;
            return ($numero == 100) ? 'cien' : $centenas[$centena] . ($resto ? ' ' . $this->convertir_cientos($resto, $unidades, $decenas, $especiales, $centenas) : '');
        }

        return '';
    }


    public function data_factura(stdClass $cfdi_sellado, string $name_entidad_sellado)
    {
        $data = $this->data_init_limpio();
        if (errores::$error) {
            return $this->error->error(mensaje: 'Error al asignar datos', data: $data);
        }

        if ($cfdi_sellado->n_registros > 0) {

            $data = $this->data_init(cfdi_sellado: $cfdi_sellado, name_entidad_sellado: $name_entidad_sellado);
            if (errores::$error) {
                return $this->error->error(mensaje: 'Error al asignar datos', data: $data);
            }

        }
        return $data;
    }

    private function data_init(stdClass $cfdi_sellado, string $name_entidad_sellado): stdClass
    {
        $folio_fiscal = $cfdi_sellado->registros[0][$name_entidad_sellado . '_uuid'];
        $sello_cfdi = $cfdi_sellado->registros[0][$name_entidad_sellado . '_complemento_tfd_sello_cfd'];
        $sello_sat = $cfdi_sellado->registros[0][$name_entidad_sellado . '_complemento_tfd_sello_sat'];
        $complento = $cfdi_sellado->registros[0][$name_entidad_sellado . '_cadena_complemento_sat'];
        $rfc_proveedor = $cfdi_sellado->registros[0][$name_entidad_sellado . '_complemento_tfd_rfc_prov_certif'];
        $fecha_timbrado = $cfdi_sellado->registros[0][$name_entidad_sellado . '_complemento_tfd_fecha_timbrado'];
        $no_certificado = $cfdi_sellado->registros[0][$name_entidad_sellado . '_comprobante_no_certificado'];
        $no_certificado_sat = $cfdi_sellado->registros[0][$name_entidad_sellado . '_complemento_tfd_no_certificado_sat'];

        $data = new stdClass();
        $data->folio_fiscal = $folio_fiscal;
        $data->sello_cfdi = $sello_cfdi;
        $data->sello_sat = $sello_sat;
        $data->complento = $complento;
        $data->rfc_proveedor = $rfc_proveedor;
        $data->fecha_timbrado = $fecha_timbrado;
        $data->no_certificado = $no_certificado;
        $data->no_certificado_sat = $no_certificado_sat;

        return $data;

    }

    private function data_init_limpio(): stdClass
    {
        $folio_fiscal = "-----";
        $sello_cfdi = "";
        $sello_sat = "";
        $complento = "---";
        $rfc_proveedor = "-----";
        $fecha_timbrado = "xxxx-xx-xx 00:00:00";
        $no_certificado = "-----";

        $data = new stdClass();
        $data->folio_fiscal = $folio_fiscal;
        $data->sello_cfdi = $sello_cfdi;
        $data->sello_sat = $sello_sat;
        $data->complento = $complento;
        $data->rfc_proveedor = $rfc_proveedor;
        $data->fecha_timbrado = $fecha_timbrado;
        $data->no_certificado = $no_certificado;
        $data->no_certificado_sat = '';

        return $data;

    }

    private function fecha_hora_emision(stdClass $data, Fpdi $pdf, int $x): true
    {
        $fecha_hora_emision = '';
        if (isset($data->fecha_timbrado)) {
            $fecha_hora_emision = $data->fecha_timbrado;
        }

        $pdf->SetXY($x, 22);
        $pdf->Write(10, $fecha_hora_emision);

        return true;

    }

    private function folio(string $tabla, array $factura, Fpdi $pdf, float $x): true
    {
        $pdf->SetFont('Arial', 'B', '10');
        $pdf->SetTextColor(255, 255, 255);
        $pdf->SetXY($x, 0);
        $pdf->Write(10, $factura[$tabla . "_folio"]);

        return true;

    }

    private function init(Fpdi $pdf): true|array
    {
        $generales = new generales();
        try {
            $pdf->addPage();
            $pdf->setSourceFile($generales->ruta_factura_pdf);
            $tplIdx = $pdf->importPage(1);
            $pdf->useTemplate($tplIdx, 0, 0, null, null, true);
        } catch (Throwable $e) {
            return (new errores())->error(mensaje: 'Error al cargar template', data: $e);
        }
        return true;
    }

    // nuevo 
    private function buildCfg(array $factura): array
    {
        $cfg = [
            'regimen_w' => 65,
            'dom_txt'   => ':',
        ];

        // si tienes un "layout" o "plantilla" en BD, usa eso aquí
        if (($factura['layout'] ?? '') === 'telj') {
            $cfg['regimen_w'] = 90;
        }


        return $cfg;
    }
    // aca termina

    private function header(string $tabla, stdClass $data, array $factura, Fpdi $pdf)
    {
        $x = 179;

        $folio = $this->folio(tabla: $tabla, factura: $factura, pdf: $pdf, x: $x);
        if (errores::$error) {
            return (new errores())->error(mensaje: 'Error al escribir folio', data: $folio);
        }

        $pdf->SetFont('Arial', '', '9');
        $pdf->SetTextColor(0, 0, 0);

        $x = 68;
        $pdf->SetXY($x, 10.3);
        if ($factura['org_empresa_rfc'] === "TELJ470913GY5") {
            $x = 35;
            $pdf->SetXY($x, 8.5);
        }

        $pdf->Write(10, $factura['org_empresa_razon_social']);

        $pdf->SetXY($x, 15);
        if ($factura['org_empresa_rfc'] === "TELJ470913GY5") {
            $pdf->SetXY($x, 14.5);
        }
        $pdf->Write(10, $factura['org_empresa_nombre_comercial']);

        $pdf->SetXY($x, 19);
        if ($factura['org_empresa_rfc'] === "TELJ470913GY5") {
            $pdf->SetXY($x, 18);
        }
        $pdf->Write(10, $factura['org_empresa_rfc']);

        $pdf->SetXY($x, 27);
        if ($factura['org_empresa_rfc'] === "TELJ470913GY5") {
            $pdf->SetXY($x, 25.5);
        }

        $regimen = $this->regimen(factura: $factura);
        if (errores::$error) {
            return (new errores())->error(mensaje: 'Error al obtener $regimen', data: $regimen);
        }
        $this->cfg = $this->buildCfg($factura);
        $regimenW = (float)($this->cfg['regimen_w'] ?? 65);
        $pdf->MultiCell($regimenW, 2.5, $regimen, 0, 'L');
        $pdf->SetXY($x, 31.5);

        $cpEmisor = trim((string)($factura['org_empresa_cp_txt'] ?? ''));
        $domTxt   = (string)($this->cfg['dom_txt'] ?? ':');

        $dom = mb_convert_encoding(trim($domTxt . ' ' . $cpEmisor), 'ISO-8859-1', 'UTF-8');
        $pdf->MultiCell(60, 3, $dom, 0, 'L');

        if ($factura['org_empresa_rfc'] === "FIN171207CKA") {
            $pdf->SetXY($x, 31.5);
            $dom = "Av. Vallarta 6503 - Int. C2, Col. Ciudad Granja,";
            $dom .= "45010, Zapopan, Jalisco";

            $dom = mb_convert_encoding($dom, 'ISO-8859-1', 'UTF-8');

            $pdf->MultiCell(60, 3, $dom, 0);

            $pdf->SetXY($x, 40.5);
            $tel = "+52 3338523986";
            $pdf->MultiCell(60, 3, $tel, 0);

        }
        if ($factura['org_empresa_rfc'] === "TELJ470913GY5") {
            $pdf->SetXY($x, 31.5);
            $dom = "Calle: Carlos Villaseñor 885 Jardines Alcalde";
            $dom .= "44290, Guadalajara, Jalisco";
            $dom = mb_convert_encoding($dom, 'ISO-8859-1', 'UTF-8');
            $pdf->MultiCell(80, 3, $dom, 0, 'L');

            $pdf->SetXY($x, 39.5);
            $tel = "+52 3338523986";
            $pdf->MultiCell(60, 3, $tel, 0);

        }

        $x = 140;

        $pdf->SetXY($x, 14);
        $pdf->Write(10, $factura[$tabla . '_fecha']);

        $fecha_hora_emision = $this->fecha_hora_emision(data: $data, pdf: $pdf, x: $x);
        if (errores::$error) {
            return (new errores())->error(mensaje: 'Error al escribir $fecha_hora_emision', data: $fecha_hora_emision);
        }

        $key_observaciones = $tabla . '_observaciones';
        $observaciones = trim((string)($factura[$key_observaciones] ?? ''));
        $observaciones = mb_convert_encoding($observaciones, 'ISO-8859-1', 'UTF-8');

        $pdf->SetFont('Arial', 'B', '8');
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetXY($x, 34);
        $pdf->MultiCell(50, 3.5, 'Observaciones:', 0, 'L');

        $pdf->SetFont('Arial', '', '8');
        $pdf->SetXY($x, 38);
        $pdf->MultiCell(50, 3.5, $observaciones, 0, 'L');
    }

    private function receptor(array $factura, Fpdi $pdf): void
    {

        if (!isset($factura['com_sucursal_numero_interior'])) {
            $factura['com_sucursal_numero_interior'] = '';
        }

        $uso_cfdi = trim($factura['cat_sat_uso_cfdi_codigo']) . ' ' . trim($factura['cat_sat_uso_cfdi_descripcion']);
        $uso_cfdi = trim($uso_cfdi);
        $uso_cfdi = mb_convert_encoding($uso_cfdi, 'ISO-8859-1', 'UTF-8');

        $x = 33;


        $pdf->SetXY($x, 52.3);
        $pdf->Write(10, mb_convert_encoding($factura['com_cliente_razon_social'], 'ISO-8859-1', 'UTF-8'));


        $pdf->SetXY($x, 57.8);
        $pdf->Write(10, $factura['com_cliente_rfc']);

        $pdf->SetXY($x, 62);
        $pdf->Write(10, $uso_cfdi);

        $pdf->SetXY($x, 68.5);
        $domicilio_receptor = trim($factura['com_sucursal_calle']);
        $domicilio_receptor = trim($domicilio_receptor) . ' ' . trim($factura['com_sucursal_numero_exterior']);
        $domicilio_receptor = trim($domicilio_receptor) . ' ' . trim($factura['com_sucursal_numero_interior']);
        $domicilio_receptor = trim($domicilio_receptor) . ' ' . trim($factura['com_sucursal_municipio']);
        $domicilio_receptor = trim($domicilio_receptor) . ' ' . trim($factura['com_sucursal_estado']);
        $domicilio_receptor = trim($domicilio_receptor) . ' ' . $factura['com_sucursal_cp'];
        $domicilio_receptor = mb_convert_encoding($domicilio_receptor, 'ISO-8859-1', 'UTF-8');
        $pdf->MultiCell(72, 5, $domicilio_receptor, 0, 'L');

        $reg = mb_convert_encoding($factura['cat_sat_regimen_fiscal_cliente_codigo'] . ' ' . $factura['cat_sat_regimen_fiscal_cliente_descripcion'], 'ISO-8859-1', 'UTF-8');
        $reg = trim($reg);
        $pdf->SetXY($x, 82);
        $pdf->MultiCell(70, 2.7, $reg);

    }

    private function regimen(array $factura): array|false|string|null
    {
        return mb_convert_encoding(trim($factura['cat_sat_regimen_fiscal_codigo'] . ' ' . $factura['cat_sat_regimen_fiscal_descripcion']), 'ISO-8859-1', 'UTF-8');
    }

    private function fiscales(stdClass $data, Fpdi $pdf): void
    {
        $x = 109;
        $pdf->SetXY($x, 53);

        $folio_fiscal = '';
        if (isset($data->folio_fiscal)) {
            $folio_fiscal = $data->folio_fiscal;
        }

        $no_certificado = '';
        if (isset($data->no_certificado)) {
            $no_certificado = $data->no_certificado;
        }

        $no_certificado_sat = '';
        if (isset($data->no_certificado_sat)) {
            $no_certificado_sat = $data->no_certificado_sat;
        }

        $pdf->Write(10, $folio_fiscal);
        $pdf->SetXY($x, 61);
        $pdf->Write(10, $no_certificado);
        $pdf->SetXY($x, 69);
        $pdf->Write(10, $no_certificado_sat);

    }

    private function pago(array $factura, Fpdi $pdf): void
    {
        $x = 38;
        $pdf->SetXY($x, 138.8);
        $pdf->Write(10, mb_convert_encoding($factura['cat_sat_forma_pago_codigo'] . ' ' . $factura['cat_sat_forma_pago_descripcion'], 'ISO-8859-1', 'UTF-8'));

        $pdf->SetXY($x, 142);
        $pdf->Write(10, mb_convert_encoding($factura['cat_sat_metodo_pago_codigo'] . ' ' . $factura['cat_sat_metodo_pago_descripcion'], 'ISO-8859-1', 'UTF-8'));

        $pdf->SetXY($x, 146);
        $pdf->Write(10, mb_convert_encoding($factura['cat_sat_tipo_de_comprobante_codigo'] . ' ' . $factura['cat_sat_tipo_de_comprobante_descripcion'], 'ISO-8859-1', 'UTF-8'));

        $pdf->SetXY($x, 149);
        $pdf->Write(10, mb_convert_encoding($factura['cat_sat_metodo_pago_descripcion'], 'ISO-8859-1', 'UTF-8'));

        $pdf->SetXY($x, 153);
        $pdf->Write(10, mb_convert_encoding($factura['cat_sat_moneda_codigo'] . ' ' . $factura['cat_sat_moneda_descripcion'], 'ISO-8859-1', 'UTF-8'));

    }

    private function montos(string $tabla, array $factura, Fpdi $pdf): void
    {

        $pdf->SetFont('Arial', 'B', '9');
        $pdf->SetTextColor(255, 255, 255);
        $fmt = new NumberFormatter('es_MX', NumberFormatter::CURRENCY);
        $x = 172;
        $y = 136;

        $fc_factura_sub_total = round($factura[$tabla.'_sub_total'], 2);
        $fc_factura_sub_total = $fmt->formatCurrency($fc_factura_sub_total, "MXN");
        $pdf->SetXY($x, $y);
        $pdf->Write(10, $fc_factura_sub_total);

        $y = $y + 5.5;

        $fc_factura_descuento = round($factura[$tabla.'_descuento'], 2);
        $fc_factura_descuento = $fmt->formatCurrency($fc_factura_descuento, "MXN");
        $pdf->SetXY($x, $y);
        $pdf->Write(10, $fc_factura_descuento);

        $y = $y + 4.7;

        $fc_factura_total_traslados = round($factura[$tabla.'_total_traslados'], 2);
        $fc_factura_total_traslados = $fmt->formatCurrency($fc_factura_total_traslados, "MXN");
        $pdf->SetXY($x, $y);
        $pdf->Write(10, $fc_factura_total_traslados);
        $y = $y + 5;


        $fc_factura_total_retenciones = round($factura[$tabla.'_total_retenciones'], 2);
        $fc_factura_total_retenciones = $fmt->formatCurrency($fc_factura_total_retenciones, "MXN");
        $pdf->SetXY($x, $y);
        $pdf->Write(10, $fc_factura_total_retenciones);

        $y = $y + 5;

        $fc_factura_total_retenciones = round($factura[$tabla.'_total_retenciones'], 2);
        $fc_factura_total_retenciones = $fmt->formatCurrency($fc_factura_total_retenciones, "MXN");
        $pdf->SetXY($x, $y);
        $pdf->Write(10, $fc_factura_total_retenciones);

        $y = $y + 4.4;
        $fc_factura_total = round($factura[$tabla.'_total'], 2);
        $fc_factura_total = $fmt->formatCurrency($fc_factura_total, "MXN");
        $pdf->SetXY($x, $y);
        $pdf->Write(10, $fc_factura_total);

        $pdf->SetTextColor(0, 0, 0);
        $fc_factura_total = round($factura[$tabla.'_total'], 2);


        $formatterES = new NumberFormatter("es-ES", NumberFormatter::SPELLOUT);
        $izquierda = intval(floor($fc_factura_total));
        $derecha = intval(($fc_factura_total - floor($fc_factura_total)) * 100);
        $letra = $formatterES->format($izquierda) . " pesos ";
        if ((float)$derecha === 0.0) {
            $derecha = '00';
        }
        $letra .= $derecha . "/100 M.N.";

        $letra = strtoupper($letra);
        $letra = mb_convert_encoding($letra, 'ISO-8859-1', 'UTF-8');
        $x = 65;
        $y = $y + 12;
        $pdf->SetXY($x, $y);
        $pdf->MultiCell(144, 2, $letra, 0, 'R');

    }

    private function sellos(stdClass $data, Fpdi $pdf): void
    {
        $x = 59;
        $pdf->SetFont('Arial', '', '7');
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetXY($x, 204);
        $pdf->MultiCell(149, 2.6, $data->complento, 0);

        $pdf->SetXY($x, 226);
        $pdf->MultiCell(149, 2.6, $data->sello_cfdi, 0);

        $pdf->SetXY($x, 248.5);
        $pdf->MultiCell(149, 2.6, $data->sello_sat, 0);

    }

    private function base_pdf(string $tabla, stdClass $data, array $factura, Fpdi $pdf, array $relacionadas,
                              string            $ruta_logo, string $ruta_qr)
    {
        $init = $this->init($pdf);
        if (errores::$error) {
            return (new errores())->error(mensaje: 'Error al cargar template', data: $init);
        }

        $this->header(tabla: $tabla, data: $data, factura: $factura, pdf: $pdf);
        $this->receptor(factura: $factura, pdf: $pdf);
        $this->fiscales(data: $data, pdf: $pdf);
        $this->pago(factura: $factura, pdf: $pdf);


        if (count($relacionadas) > 0) {
            $y = 165;
            $pdf->SetXY(7, $y);
            $pdf->SetFont('Arial', 'B', '9');
            $pdf->SetTextColor(0, 0, 0);
            $pdf->MultiCell(90, 3, 'Relaciones:', 0);
            foreach ($relacionadas as $relacionada) {
                $pdf->SetFont('Arial', 'B', '8');
                $cat_sat_tipo_relacion_codigo = trim($relacionada['cat_sat_tipo_relacion_codigo']);
                $cat_sat_tipo_relacion_descripcion = trim($relacionada['cat_sat_tipo_relacion_descripcion']);

                $tipo_relacion = "$cat_sat_tipo_relacion_codigo $cat_sat_tipo_relacion_descripcion";
                $tipo_relacion = mb_convert_encoding($tipo_relacion, 'ISO-8859-1', 'UTF-8');
                $y = $y + 4;
                $pdf->SetFont('Arial', 'B', '8');
                $pdf->SetXY(8.5, $y);
                $pdf->MultiCell(90, 3.5, $tipo_relacion, 0);

                $folios_rel = $relacionada['fc_facturas_relacionadas'];

                foreach ($folios_rel as $folio_rel) {
                    $y = $y + 4;
                    $pdf->SetXY(9.5, $y);
                    $pdf->SetFont('Arial', '', '7');
                    $pdf->MultiCell(90, 3.5, $folio_rel['fc_factura_uuid'], 0);

                }


            }
        }


        $this->montos(tabla: $tabla,factura: $factura, pdf: $pdf);
        $this->sellos(data: $data, pdf: $pdf);
        if ($ruta_qr !== '') {
            if (file_exists($ruta_qr)) {
                $pdf->SetXY(10, 196);
                $pdf->Image($ruta_qr, null, null, 45, 45, 'png');
            }
        }
        if ($ruta_logo !== '') {
            if (file_exists($ruta_logo)) {
                $pdf->SetXY(10, 10);
                $pdf->Image($ruta_logo, null, null, 35, 0, 'png');
            }
        }


    }

   final public function pdf(bool              $descarga, bool $guarda, PDO $link, _doc $modelo_documento,
                              _transacciones_fc $modelo_entidad, _partida $modelo_partida,
                              _cuenta_predial   $modelo_predial, _relacion $modelo_relacion,
                              _relacionada      $modelo_relacionada, _data_impuestos $modelo_retencion,
                              _sellado          $modelo_sellado, _data_impuestos $modelo_traslado, _uuid_ext $modelo_uuid_ext,
                              int               $registro_id): array|string|bool
    {

        $factura = $modelo_entidad->get_factura(modelo_partida: $modelo_partida,
            modelo_predial: $modelo_predial, modelo_relacion: $modelo_relacion,
            modelo_relacionada: $modelo_relacionada, modelo_retencion: $modelo_retencion,
            modelo_traslado: $modelo_traslado, modelo_uuid_ext: $modelo_uuid_ext, registro_id: $registro_id);
        if (errores::$error) {
            return $this->error->error(mensaje: 'Error al obtener factura', data: $factura);
        }

        // nuevo
        $cpEmisorId = (int)($factura['org_empresa_dp_cp_id'] ?? 0);
        $factura['org_empresa_cp_txt'] = $this->cp_txt($link, $cpEmisorId);
        //aca termina

        $ruta_qr = $modelo_documento->get_factura_documento(key_entidad_filter_id: $modelo_entidad->key_filtro_id,
            registro_id: $registro_id, tipo_documento: "qr_cfdi");
        if (errores::$error) {
            return $this->error->error(mensaje: 'Error al obtener QR', data: $ruta_qr);
        }

        // LOGO dinámico: principal activo por empresa
        $filtro = array();
        $filtro['org_logo.status'] = 'activo';
        $filtro['org_logo.logo_pdf'] = 'activo';
        $filtro['org_logo.org_empresa_id'] = (int)$factura['org_empresa_id'];

        $r_org_logo = (new org_logo(link: $link))->filtro_and(
            aplica_seguridad: false,
            columnas: ['doc_documento_ruta_absoluta'],
            filtro: $filtro,
            limit: 1,
            order: ['org_logo.id' => 'DESC']
        );
        if (errores::$error) {
            return $this->error->error(mensaje: 'Error al obtener Logo', data: $r_org_logo);
        }

        $ruta_logo = '';
        if ($r_org_logo->n_registros > 0) {
            $ruta_logo = (string)$r_org_logo->registros[0]['doc_documento_ruta_absoluta'];
        }
        // aca termina logo dinámico

        $filtro = array();
        $filtro[$modelo_entidad->key_id] = $factura[$modelo_entidad->key_id];
        $cfdi_sellado = $modelo_sellado->filtro_and(filtro: $filtro);
        if (errores::$error) {
            return $this->error->error(mensaje: 'Error al obtener cfdi_sellado', data: $cfdi_sellado);
        }

        $cod_postal_receptor = $factura['com_sucursal_cp'];

        $rf_emisor = (new cat_sat_regimen_fiscal($link))->registro(
            $factura["org_empresa_cat_sat_regimen_fiscal_id"]);
        if (errores::$error) {
            return $this->error->error(mensaje: 'Error al obtener regimen fiscal emisor', data: $rf_emisor);
        }

        $rf_receptor = (new cat_sat_regimen_fiscal($link))->registro(
            $factura["com_cliente_cat_sat_regimen_fiscal_id"]);
        if (errores::$error) {
            return $this->error->error(mensaje: 'Error al obtener regimen fiscal receptor', data: $rf_receptor);
        }

        $data = $this->data_factura(cfdi_sellado: $cfdi_sellado, name_entidad_sellado: $modelo_sellado->tabla);
        if (errores::$error) {
            return $this->error->error(mensaje: 'Error al asignar datos', data: $data);
        }

        $relacionadas = $modelo_entidad->get_data_relaciones(modelo_relacion: $modelo_relacion,
            modelo_relacionada: $modelo_relacionada, modelo_uuid_ext: $modelo_uuid_ext, registro_entidad_id: $registro_id);
        if (errores::$error) {
            return $this->error->error(mensaje: 'Error al obtener relacionadas', data: $relacionadas);
        }

        $key_observaciones = $modelo_entidad->tabla . '_observaciones';
        if (!isset($factura[$key_observaciones])) {
            $factura[$key_observaciones] = '';
        }

        $key_exportacion = $modelo_entidad->tabla . '_exportacion';
        $key_fecha = $modelo_entidad->tabla . '_fecha';
        $key_folio = $modelo_entidad->tabla . '_folio';

        $aplica_plantilla = false;
        $generales = new generales();

        if (!isset($generales->ruta_factura_pdf)) {
            return $this->error->error(mensaje: 'Error no existe la propiedad ruta_factura_pdf', data: $generales);
        }

        if ($generales->ruta_factura_pdf) {
            if (file_exists($generales->ruta_factura_pdf)) {
                $aplica_plantilla = true;
            }
        }

        if (!$aplica_plantilla) {
            $pdf = new pdf();
            $pdf->header(cfdi: $factura['cat_sat_uso_cfdi_descripcion'], cod_postal: $factura['dp_cp_descripcion'],
                cod_postal_receptor: $cod_postal_receptor, csd: $factura['fc_csd_serie'],
                efecto: $factura['cat_sat_tipo_de_comprobante_descripcion'],
                exportacion: $factura[$key_exportacion], fecha: $factura[$key_fecha],
                folio: $factura[$key_folio], folio_fiscal: $data->folio_fiscal,
                nombre_emisor: $factura['org_empresa_razon_social'], nombre_receptor: $factura['com_cliente_razon_social'],
                observaciones: $factura[$key_observaciones],
                regimen_fiscal: $rf_emisor['cat_sat_regimen_fiscal_descripcion'],
                regimen_fiscal_receptor: $rf_receptor['cat_sat_regimen_fiscal_descripcion'],
                rfc_emisor: $factura['org_empresa_rfc'], rfc_receptor: $factura['com_cliente_rfc'], ruta_logo: $ruta_logo);
            if (errores::$error) {
                return $this->error->error(mensaje: 'Error al maquetar header', data: $pdf);
            }

        } else {

            $tabla = $modelo_entidad->tabla;
            $tabla_partida = $modelo_partida->tabla;

            $fmt = new NumberFormatter('es_MX', NumberFormatter::CURRENCY);
            $pdf = new Fpdi();

            // ── PLANTILLA CUSTOM OPCIONAL ──
            // Si generales NO tiene plantilla_tipo, está vacío, vale "default"
            // o no existe el método base correspondiente, se conserva el flujo
            // original de esta función sin exigir nuevas variables a otros sistemas.
            $plantilla_tipo = null;
            $metodo_base = null;
            $usa_plantilla_custom = false;

            if (isset($generales->plantilla_tipo)) {
                $plantilla_tipo = trim((string)$generales->plantilla_tipo);

                if ($plantilla_tipo !== '' && $plantilla_tipo !== 'default') {
                    $metodo_base = 'base_pdf_' . $plantilla_tipo;
                    $usa_plantilla_custom = method_exists($this, $metodo_base);
                }
            }

            if ($usa_plantilla_custom) {

                // Renderer completo opcional por plantilla:
                // render_documento_ivitec(), render_documento_artistik(), etc.
                // Si no existe, la plantilla mantiene el flujo custom anterior.
                $metodo_render_documento = 'render_documento_' . $plantilla_tipo;

                if (method_exists($this, $metodo_render_documento)) {

                    $this->$metodo_render_documento(
                        tabla: $tabla,
                        tabla_partida: $tabla_partida,
                        factura: $factura,
                        pdf: $pdf,
                        fmt: $fmt,
                        data: $data,
                        relacionadas: $relacionadas,
                        ruta_logo: $ruta_logo,
                        ruta_qr: $ruta_qr
                    );

                } else {

                    // ── FLUJO CUSTOM EXISTENTE (sin cambios) ──
                    $this->$metodo_base(tabla: $tabla, data: $data, factura: $factura, pdf: $pdf,
                        relacionadas: $relacionadas, ruta_logo: $ruta_logo, ruta_qr: $ruta_qr);

                    $this->render_partidas_custom(
                        plantilla_tipo: $plantilla_tipo,
                        tabla: $tabla,
                        tabla_partida: $tabla_partida,
                        factura: $factura,
                        pdf: $pdf,
                        fmt: $fmt,
                        data: $data,
                        relacionadas: $relacionadas,
                        ruta_logo: $ruta_logo,
                        ruta_qr: $ruta_qr
                    );
                }

            } else {

                // ── FLUJO DEFAULT (original, intacto) ──
                $this->base_pdf(tabla: $tabla, data: $data, factura: $factura, pdf: $pdf, relacionadas: $relacionadas,
                    ruta_logo: $ruta_logo, ruta_qr: $ruta_qr);

                $border = 0;
                $h = 2.5;
                $y = 96.5;
                $partidas = 1;
                foreach ($factura['partidas'] as $partida) {
                    $pdf->SetFont('Arial', '', '7');
                    $x = 7;
                    $pdf->SetXY($x, $y);
                    $pdf->MultiCell(10, $h, $partida[$tabla_partida.'_cantidad'], $border, 'C');

                    $x = 19;
                    $pdf->SetXY($x, $y);
                    $pdf->MultiCell(12, $h, $partida['cat_sat_unidad_codigo'], $border, 'C');

                    $x = 33;
                    $pdf->SetXY($x, $y);
                    $pdf->MultiCell(18, $h, $partida['com_producto_codigo_sat'], $border, 'C');

                    $x = 52;
                    $pdf->SetXY($x, $y);
                    $pdf->MultiCell(75, $h, mb_convert_encoding($partida[$tabla_partida.'_descripcion'], 'ISO-8859-1', 'UTF-8'), $border, 'L');

                    $x = 127;
                    $pdf->SetXY($x, $y);
                    $pdf->MultiCell(27, $h,
                        mb_convert_encoding($partida['cat_sat_obj_imp_descripcion'], 'ISO-8859-1', 'UTF-8'), $border, 'C');

                    $fc_partida_valor_unitario = round($partida[$tabla_partida.'_valor_unitario'], 2);
                    $fc_partida_valor_unitario = $fmt->formatCurrency($fc_partida_valor_unitario, "MXN");

                    $x = 155;
                    $pdf->SetXY($x, $y);
                    $pdf->MultiCell(24, $h, $fc_partida_valor_unitario, $border, 'C');

                    $fc_partida_sub_total = round($partida[$tabla_partida.'_sub_total'], 2);
                    $fc_partida_sub_total = $fmt->formatCurrency($fc_partida_sub_total, "MXN");

                    $x = 182;
                    $pdf->SetXY($x, $y);
                    $pdf->MultiCell(24, $h, $fc_partida_sub_total, $border, 'C');

                    $y = $y + $h;

                    $partidas++;
                    $mod = $partidas % 6;
                    if ($mod === 0) {
                        $y = 96.5;
                        $this->base_pdf(tabla: $tabla, data: $data, factura: $factura, pdf: $pdf, relacionadas: $relacionadas, ruta_logo: $ruta_logo, ruta_qr: $ruta_qr);
                    }
                }
                $this->leyenda(pdf: $pdf);

            }

            // nuevo nombre del pdf de factura
            $key_serie = $modelo_entidad->tabla . '_serie';
            $key_folio = $modelo_entidad->tabla . '_folio';

            $add_razon_total = '';
            if ($this->cambios_titulo_pdf) {
                $razon_social = preg_replace('/[^A-Za-z0-9_\-]/', '_', $factura['com_cliente_razon_social']);
                $total = number_format(
                    (float)($factura[$modelo_entidad->tabla . '_sub_total'] ?? 0)
                    + (float)($factura[$modelo_entidad->tabla . '_total_traslados'] ?? 0)
                    - (float)($factura[$modelo_entidad->tabla . '_total_retenciones'] ?? 0),
                    2, '.', ''
                );
                $add_razon_total = '_' . $razon_social . '_' . $total;
            }

            $nombre_documento = $factura[$key_serie] . $factura[$key_folio] . $add_razon_total;

            if ($descarga) {
                $pdf->Output($nombre_documento . '.pdf', 'D');
                return $nombre_documento;
            }
            if ($guarda) {
                $path_base = (new generales())->path_base;
                $path_base_archivos = $path_base . 'archivos';
                if (!file_exists($path_base_archivos)) {
                    mkdir($path_base_archivos);
                }
                $nombre_documento = $path_base_archivos . '/' . $nombre_documento . '.pdf';

                $pdf->Output('F', $nombre_documento);
                return $nombre_documento;
            }

            $pdf->Output();

        }

        $rs = $pdf->data_relacionados(name_entidad: $modelo_entidad->tabla, relacionadas: $relacionadas);
        if (errores::$error) {
            return $this->error->error(mensaje: 'Error al maquetar relacionadas', data: $rs);
        }

        if ($modelo_entidad->tabla !== 'fc_complemento_pago') {
            $rs = $pdf->conceptos(conceptos: $factura['partidas'], link: $link, name_entidad_partida: $modelo_partida->tabla);
            if (errores::$error) {
                return $this->error->error(mensaje: 'Error al maquetar conceptos', data: $rs);
            }
        }

        if ($modelo_entidad->tabla === 'fc_complemento_pago') {

            $r_fc_pago_pago = (new fc_pago_pago(link: $link))->filtro_and(filtro: $filtro);
            if (errores::$error) {
                return $this->error->error(mensaje: 'Error al maquetar conceptos', data: $r_fc_pago_pago);
            }
            $fc_pago_pagos = $r_fc_pago_pago->registros;

            $r_fc_pago_total = (new fc_pago_total(link: $link))->filtro_and(filtro: $filtro);
            if (errores::$error) {
                return $this->error->error(mensaje: 'Error al maquetar conceptos', data: $r_fc_pago_total);
            }
            $fc_pago_totales = $r_fc_pago_total->registros;

            $r_fc_docto_relacionado = (new fc_docto_relacionado(link: $link))->filtro_and(filtro: $filtro);
            if (errores::$error) {
                return $this->error->error(mensaje: 'Error al maquetar conceptos', data: $r_fc_docto_relacionado);
            }
            $fc_doctos_relacionados = $r_fc_docto_relacionado->registros;

            $rs = $pdf->complemento_pago(fc_doctos_relacionados: $fc_doctos_relacionados, fc_pago_pagos: $fc_pago_pagos,
                fc_pago_totales: $fc_pago_totales);
            if (errores::$error) {
                return $this->error->error(mensaje: 'Error al maquetar conceptos', data: $rs);
            }
        }

        $key_sub_total_base = $modelo_entidad->tabla . '_sub_total_base';
        $key_total = $modelo_entidad->tabla . '_total';

        $pdf->totales(descuento: $factura['total_descuento'], moneda: $factura['cat_sat_moneda_descripcion'],
            subtotal: $factura[$key_sub_total_base], forma_pago: $factura['cat_sat_forma_pago_descripcion'],
            imp_trasladados: $factura['total_impuestos_trasladados'],
            imp_retenidos: $factura['total_impuestos_retenidos'],
            metodo_pago: $factura['cat_sat_metodo_pago_descripcion'], total: $factura[$key_total]);
        if (errores::$error) {
            return $this->error->error(mensaje: 'Error al maquetar totales', data: $pdf);
        }

        $pdf->complementos(ruta_documento: $ruta_qr, complento: $data->complento, rfc_proveedor: $data->rfc_proveedor,
            fecha: $data->fecha_timbrado, no_certificado: $data->no_certificado);
        if (errores::$error) {
            return $this->error->error(mensaje: 'Error al maquetar complementos', data: $pdf);
        }

        $pdf->sellos(sello_cfdi: $data->sello_cfdi, sello_sat: $data->sello_sat);
        if (errores::$error) {
            return $this->error->error(mensaje: 'Error al maquetar sellos', data: $pdf);
        }

        $pdf->footer(descripcion: "efacturacion.com.mx");
        if (errores::$error) {
            return $this->error->error(mensaje: 'Error al generar pdf', data: $pdf);
        }

        $key_serie = $modelo_entidad->tabla . '_serie';
        $key_folio = $modelo_entidad->tabla . '_folio';

        $nombre_documento = $factura[$key_serie] . $factura[$key_folio];

        $nombre_documento = $pdf->guardar(nombre_documento: $nombre_documento, descarga: $descarga, guarda: $guarda);
        if (errores::$error) {
            return $this->error->error(mensaje: 'Error al generar pdf', data: $pdf);
        }
        return $nombre_documento;
    }

    // nuevo 
    /**
 * Obtiene el CP (texto) desde dp_cp por id.
 * Devuelve '' si no existe o viene vacío.
 */
    private function cp_txt(PDO $link, int $dp_cp_id): string
    {
        if ($dp_cp_id <= 0) {
            return '';
        }

        $sql = "SELECT descripcion FROM dp_cp WHERE id = :id LIMIT 1";
        $stmt = $link->prepare($sql);
        $stmt->execute([':id' => $dp_cp_id]);

        $val = $stmt->fetchColumn();
        if ($val === false || $val === null) {
            return '';
        }

        return trim((string)$val);
    }

   private function leyenda(Fpdi $pdf): void
    {
        if (!$this->leyenda_factura_pdf) {
            return;
        }

        $texto = "En caso de aclaración o corrección de la factura emitida, "
            . "tendrá sólo tres días a partir de la expedición de la misma, "
            . "para solicitarlo; de lo contrario no se podrá realizar "
            . "modificación alguna. Gracias.";

        $texto = mb_convert_encoding($texto, 'ISO-8859-1', 'UTF-8');

       $pdf->SetAutoPageBreak(false);
        $pdf->SetFont('Arial', 'B', 8);            
        $pdf->SetTextColor(0, 0, 0);               
        $pdf->SetXY(7, 273);                      
        $pdf->MultiCell(196, 2.5, $texto, 0, 'C');
        $pdf->SetAutoPageBreak(true);         
    }
  private function base_pdf_artistik(string $tabla, stdClass $data, array $factura, Fpdi $pdf,
                                       array $relacionadas, string $ruta_logo, string $ruta_qr): void
    {
        $init = $this->init($pdf); // carga la plantilla (landscape 279.4 x 215.9)
        if (errores::$error) {
            return;
        }

        // Página horizontal de 215.9mm de alto: sin salto automático,
        // todo se posiciona manualmente dentro de la página
        $pdf->SetAutoPageBreak(false);

        // El logo YA viene incluido en la plantilla — no se estampa nada encima

        $this->header_artistik(tabla: $tabla, data: $data, factura: $factura, pdf: $pdf);
        $this->receptor_artistik(factura: $factura, pdf: $pdf);
        $this->pago_artistik(factura: $factura, pdf: $pdf);
        $this->montos_artistik(tabla: $tabla, factura: $factura, pdf: $pdf);
    }


    // ─────────────────────────────────────────────
    // HEADER — Folio | Fecha de emisión | Lugar de expedición
    // + Observaciones (caja inferior central)
    // ─────────────────────────────────────────────
    private function header_artistik(string $tabla, stdClass $data, array $factura, Fpdi $pdf): void
    {
        $pdf->SetFont('Arial', '', '9');
        $pdf->SetTextColor(0, 0, 0);

        // Fila de info: texto centrado verticalmente en y=65.3 → SetY = 65.3 - 5 (Write h=10)
        $y_fila_info = 60.3;

        // Folio (etiqueta termina en x=39.1)
        $pdf->SetXY(43, $y_fila_info);
        $pdf->Write(10, $factura[$tabla . '_folio']);

        // Fecha de emisión (etiqueta termina en x=138.3)
        $pdf->SetXY(141, $y_fila_info);
        $pdf->Write(10, $factura[$tabla . '_fecha']);

        // Lugar de expedición / CP emisor (etiqueta termina en x=222.1)
        $cpEmisor = trim((string)($factura['org_empresa_cp_txt'] ?? ''));
        $pdf->SetXY(225, $y_fila_info);
        $pdf->Write(10, $cpEmisor);

        // Observaciones (caja inferior central: x 104-186.7, y 173-203.4)
        $key_observaciones = $tabla . '_observaciones';
        $observaciones = trim((string)($factura[$key_observaciones] ?? ''));
        if ($observaciones !== '') {
            $observaciones = mb_convert_encoding($observaciones, 'ISO-8859-1', 'UTF-8');
            $pdf->SetFont('Arial', '', '8');
            $pdf->SetXY(109, 186);
            $pdf->MultiCell(73, 3.5, $observaciones, 0, 'L');
        }
    }


    // ─────────────────────────────────────────────
    // RECEPTOR — Caja CLIENTE (x 16.6-137.8)
    // Valores a la derecha de cada etiqueta, x=64
    // ─────────────────────────────────────────────
    private function receptor_artistik(array $factura, Fpdi $pdf): void
    {
        if (!isset($factura['com_sucursal_numero_interior'])) {
            $factura['com_sucursal_numero_interior'] = '';
        }

        $pdf->SetFont('Arial', '', '8');
        $pdf->SetTextColor(0, 0, 0);

        $x = 64; // después de la etiqueta más larga ("Nombre / Razón social" termina en 61.3)

        // Nombre / Razón social (etiqueta centrada en y=92.6 → SetY = 92.6 - 5)
        $pdf->SetXY($x, 87.6);
        $pdf->Write(10, mb_convert_encoding($factura['com_cliente_razon_social'], 'ISO-8859-1', 'UTF-8'));

        // RFC (centrado en y=102.2)
        $pdf->SetXY($x, 97.2);
        $pdf->Write(10, $factura['com_cliente_rfc']);

        // Domicilio (centrado en y=111.7) — MultiCell por si toma 2 líneas
        $domicilio = trim($factura['com_sucursal_calle']);
        $domicilio .= ' ' . trim($factura['com_sucursal_numero_exterior']);
        $domicilio .= ' ' . trim($factura['com_sucursal_numero_interior']);
        $domicilio .= ', ' . trim($factura['com_sucursal_municipio']);
        $domicilio .= ', ' . trim($factura['com_sucursal_estado']);
        $domicilio .= ' ' . $factura['com_sucursal_cp'];
        $domicilio = mb_convert_encoding($domicilio, 'ISO-8859-1', 'UTF-8');

        $pdf->SetXY($x, 108.5);
        $pdf->MultiCell(71, 3.5, $domicilio, 0, 'L');
    }


    // ─────────────────────────────────────────────
    // PAGO — Caja derecha (x 141.4-262.4)
    // Valores después de las etiquetas, x=193
    // ─────────────────────────────────────────────
    private function pago_artistik(array $factura, Fpdi $pdf): void
    {
        $pdf->SetFont('Arial', '', '8');
        $pdf->SetTextColor(0, 0, 0);

        $x = 193; // la etiqueta más larga ("Uso o concepto del pago") termina en x=190

        // Método de pago (etiqueta centrada en y=83.6)
        $metodo = $factura['cat_sat_metodo_pago_codigo'] . ' ' . $factura['cat_sat_metodo_pago_descripcion'];
        $pdf->SetXY($x, 78.6);
        $pdf->Write(10, mb_convert_encoding($metodo, 'ISO-8859-1', 'UTF-8'));

        // Forma de pago (y=92.9)
        $forma = $factura['cat_sat_forma_pago_codigo'] . ' ' . $factura['cat_sat_forma_pago_descripcion'];
        $pdf->SetXY($x, 87.9);
        $pdf->Write(10, mb_convert_encoding($forma, 'ISO-8859-1', 'UTF-8'));

        // Moneda (y=102.0)
        $moneda = $factura['cat_sat_moneda_codigo'] . ' ' . $factura['cat_sat_moneda_descripcion'];
        $pdf->SetXY($x, 97.0);
        $pdf->Write(10, mb_convert_encoding($moneda, 'ISO-8859-1', 'UTF-8'));

        // Uso o concepto del pago (y=111.3)
        $uso = $factura['cat_sat_uso_cfdi_codigo'] . ' ' . $factura['cat_sat_uso_cfdi_descripcion'];
        $pdf->SetXY($x, 106.3);
        $pdf->Write(10, mb_convert_encoding($uso, 'ISO-8859-1', 'UTF-8'));
    }


    // ─────────────────────────────────────────────
    // MONTOS — Total (caja $ x 216.2-262.2, y 160.7-170.7)
    // + Importe con letra (caja x 16.6-100.6, y 173-203.4)
    // ─────────────────────────────────────────────
    private function montos_artistik(string $tabla, array $factura, Fpdi $pdf): void
    {
        // ── TOTAL: la plantilla YA imprime el "$" (en x≈230), solo va el número ──
        $pdf->SetFont('Arial', 'B', '11');
        $pdf->SetTextColor(0, 0, 0);

        $fc_total = round($factura[$tabla . '_total'], 2);
        $fc_total_fmt = number_format($fc_total, 2); // sin símbolo: el $ está en la plantilla

        $pdf->SetXY(235, 160.9); // centro vertical de la caja (165.9) - 5
        $pdf->Write(10, $fc_total_fmt);

        // ── Importe con letra ──
        $pdf->SetFont('Arial', '', '8');

        $formatterES = new NumberFormatter("es-ES", NumberFormatter::SPELLOUT);
        $izquierda = intval(floor($fc_total));
        $derecha = intval(($fc_total - floor($fc_total)) * 100);
        $letra = strtoupper($formatterES->format($izquierda)) . " PESOS ";
        if ((float)$derecha === 0.0) {
            $derecha = '00';
        }
        $letra .= $derecha . "/100 M.N.";
        $letra = mb_convert_encoding($letra, 'ISO-8859-1', 'UTF-8');

        $pdf->SetXY(22, 186); // debajo de la etiqueta "Importe con letra" (y≈180)
        $pdf->MultiCell(75, 3.5, $letra, 0, 'L');
    }

    private function render_partidas_custom(string $plantilla_tipo, string $tabla, string $tabla_partida,
                                            array $factura, Fpdi $pdf, NumberFormatter $fmt,
                                            stdClass $data, array $relacionadas,
                                            string $ruta_logo, string $ruta_qr): void
    {
        $metodo_cfg = 'cfg_partidas_' . $plantilla_tipo;
        if (!method_exists($this, $metodo_cfg)) {
            return;
        }
        $cfg = $this->$metodo_cfg();

        $border = 0; // <-- 1 para debug, 0 para producción
        $h = 3.5;
        $y = $cfg['y_inicio'];
        $count = 1;

        foreach ($factura['partidas'] as $partida) {
            $pdf->SetFont('Arial', '', '8');

            foreach ($cfg['columnas'] as $col) {
                $key = $tabla_partida . $col['key'];
                $val = $partida[$key] ?? '';

                if ($col['format'] === 'currency') {
                    $val = $fmt->formatCurrency(round((float)$val, 2), "MXN");
                } else {
                    $val = mb_convert_encoding((string)$val, 'ISO-8859-1', 'UTF-8');
                }

                $pdf->SetXY($col['x'], $y);
                $pdf->MultiCell($col['w'], $h, $val, $border, $col['align']);
            }

            $y += $cfg['row_h'];
            $count++;

            if ($count % $cfg['max_por_pagina'] === 0) {
                $y = $cfg['y_inicio'];
                $metodo_base = 'base_pdf_' . $plantilla_tipo;
                $this->$metodo_base(tabla: $tabla, data: $data, factura: $factura,
                    pdf: $pdf, relacionadas: $relacionadas, ruta_logo: $ruta_logo, ruta_qr: $ruta_qr);
            }
        }
    }


    private function cfg_partidas_artistik(): array
    {
        return [
            'y_inicio'       => 129.3,
            'row_h'          => 6.9,
            'max_por_pagina' => 4,
            'columnas'       => [
                ['key' => '_cantidad',       'x' => 17,  'w' => 32,  'align' => 'C', 'format' => 'text'],
                ['key' => '_descripcion',    'x' => 51,  'w' => 123, 'align' => 'L', 'format' => 'text'],
                ['key' => '_valor_unitario', 'x' => 176, 'w' => 43,  'align' => 'C', 'format' => 'currency'],
                ['key' => '_sub_total',      'x' => 220, 'w' => 42,  'align' => 'C', 'format' => 'currency'],
            ],
        ];
    }

  private function base_pdf_ivitec(
        string $tabla,
        stdClass $data,
        array $factura,
        Fpdi $pdf,
        array $relacionadas,
        string $ruta_logo,
        string $ruta_qr
    ): void {
        $init = $this->init($pdf);
        if (errores::$error) {
            return;
        }

        $pdf->SetAutoPageBreak(false);

        $this->header_ivitec(tabla: $tabla, data: $data, factura: $factura, pdf: $pdf);
        $this->receptor_ivitec(factura: $factura, pdf: $pdf);
        $this->comprobante_ivitec(tabla: $tabla, data: $data, factura: $factura, pdf: $pdf);
        $this->pago_ivitec(factura: $factura, pdf: $pdf);
        $this->montos_ivitec(tabla: $tabla, factura: $factura, pdf: $pdf);
        $this->fiscales_ivitec(data: $data, pdf: $pdf);
        $this->sellos_ivitec(data: $data, pdf: $pdf);

        if ($ruta_qr !== '' && file_exists($ruta_qr)) {
            $pdf->Image($ruta_qr, 16, 193, 21, 21, 'png');
        }

        // IMPORTANTE:
        // La plantilla PDF suministrada NO contiene la leyenda genérica que actualmente
        // aparece debajo del footer. Se desactiva para que IVITEC conserve su diseño.
        // Si IVITEC necesita esa leyenda, conviene crear leyenda_ivitec() con coordenadas propias.
        // $this->leyenda(pdf: $pdf);
    }


   
    private function header_ivitec(string $tabla, stdClass $data, array $factura, Fpdi $pdf): void
    {
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetFont('Arial', 'B', 8);
        $pdf->SetXY(170.75, 19.0);
        $pdf->MultiCell(33.85, 3, (string)$factura[$tabla . '_folio'], 0, 'C');

        $pdf->SetFont('Arial', '', 8);
        $pdf->SetXY(48.7, 43.8);
        $pdf->MultiCell(
            57.0,
            3,
            mb_convert_encoding((string)$factura['org_empresa_razon_social'], 'ISO-8859-1', 'UTF-8'),
            0,
            'L'
        );

        $pdf->SetXY(27.2, 49.1);
        $pdf->MultiCell(78.5, 3, (string)$factura['org_empresa_rfc'], 0, 'L');

        $regimen = $this->regimen(factura: $factura);
        if (!errores::$error) {
            $pdf->SetXY(39.9, 54.4);
            $pdf->MultiCell(65.8, 3, $regimen, 0, 'L');
        }
        $cpEmisor = trim((string)($factura['org_empresa_cp_txt'] ?? ''));
        $pdf->SetXY(46.6, 59.7);
        $pdf->MultiCell(59.1, 3, $cpEmisor, 0, 'L');
    }

    private function comprobante_ivitec(string $tabla, stdClass $data, array $factura, Fpdi $pdf): void
    {
        $pdf->SetTextColor(0, 0, 0);
        $fecha = (string)($data->fecha_timbrado ?? $factura[$tabla . '_fecha']);
        $pdf->SetFont('Arial', '', 6);
        $pdf->SetXY(141.0, 44.0);
        $pdf->MultiCell(23.0, 2.4, $fecha, 0, 'L');

        $pdf->SetFont('Arial', '', 8);
        $tipo = $factura['cat_sat_tipo_de_comprobante_codigo'] . ' ' .
            $factura['cat_sat_tipo_de_comprobante_descripcion'];
        $pdf->SetXY(176.0, 43.8);
        $pdf->MultiCell(
            24.3,
            3,
            mb_convert_encoding($tipo, 'ISO-8859-1', 'UTF-8'),
            0,
            'L'
        );

        $moneda = $factura['cat_sat_moneda_codigo'] . ' ' . $factura['cat_sat_moneda_descripcion'];
        $pdf->SetXY(132.9, 49.1);
        $pdf->MultiCell(
            31.1,
            3,
            mb_convert_encoding($moneda, 'ISO-8859-1', 'UTF-8'),
            0,
            'L'
        );

        $exportacion = (string)($factura[$tabla . '_exportacion'] ?? '');
        $pdf->SetXY(187.0, 49.1);
        $pdf->MultiCell(
            13.3,
            3,
            mb_convert_encoding($exportacion, 'ISO-8859-1', 'UTF-8'),
            0,
            'L'
        );

        $forma = $factura['cat_sat_forma_pago_codigo'] . ' ' . $factura['cat_sat_forma_pago_descripcion'];
        $pdf->SetXY(142.8, 54.4);
        $pdf->MultiCell(
            57.5,
            3,
            mb_convert_encoding($forma, 'ISO-8859-1', 'UTF-8'),
            0,
            'L'
        );

        $metodo = $factura['cat_sat_metodo_pago_codigo'] . ' ' . $factura['cat_sat_metodo_pago_descripcion'];
        $pdf->SetXY(144.9, 59.7);
        $pdf->MultiCell(
            55.4,
            3,
            mb_convert_encoding($metodo, 'ISO-8859-1', 'UTF-8'),
            0,
            'L'
        );
    }


    private function receptor_ivitec(array $factura, Fpdi $pdf): void
    {
        if (!isset($factura['com_sucursal_numero_interior'])) {
            $factura['com_sucursal_numero_interior'] = '';
        }

        $pdf->SetFont('Arial', '', 8);
        $pdf->SetTextColor(0, 0, 0);

       
        $pdf->SetXY(27.5, 81.5);
        $pdf->MultiCell(38.4, 3, (string)$factura['com_cliente_rfc'], 0, 'L');

        $pdf->SetXY(79.0, 81.5);
        $pdf->MultiCell(20.8, 3, (string)$factura['com_sucursal_cp'], 0, 'L');

        $reg = $factura['cat_sat_regimen_fiscal_cliente_codigo'] . ' ' .
            $factura['cat_sat_regimen_fiscal_cliente_descripcion'];
        $reg = mb_convert_encoding($reg, 'ISO-8859-1', 'UTF-8');
        $pdf->SetXY(121.7, 81.5);
        $pdf->MultiCell(77.2, 3, $reg, 0, 'L');

      
        $pdf->SetXY(49.4, 87.9);
        $pdf->MultiCell(
            97.0,
            3,
            mb_convert_encoding((string)$factura['com_cliente_razon_social'], 'ISO-8859-1', 'UTF-8'),
            0,
            'L'
        );

        $uso = $factura['cat_sat_uso_cfdi_codigo'] . ' ' . $factura['cat_sat_uso_cfdi_descripcion'];
        $pdf->SetXY(167.2, 87.9);
        $pdf->MultiCell(
            31.7,
            3,
            mb_convert_encoding($uso, 'ISO-8859-1', 'UTF-8'),
            0,
            'L'
        );
    }


    private function pago_ivitec(array $factura, Fpdi $pdf): void
    {
        $pdf->SetFont('Arial', '', 8);
        $pdf->SetTextColor(0, 0, 0);

        $moneda = $factura['cat_sat_moneda_codigo'] . ' ' . $factura['cat_sat_moneda_descripcion'];
        $pdf->SetXY(34.9, 156.3);
        $pdf->MultiCell(
            80.4,
            3,
            mb_convert_encoding($moneda, 'ISO-8859-1', 'UTF-8'),
            0,
            'L'
        );

        $forma = $factura['cat_sat_forma_pago_codigo'] . ' ' . $factura['cat_sat_forma_pago_descripcion'];
        $pdf->SetXY(41.6, 162.3);
        $pdf->MultiCell(
            73.7,
            3,
            mb_convert_encoding($forma, 'ISO-8859-1', 'UTF-8'),
            0,
            'L'
        );

        $metodo = $factura['cat_sat_metodo_pago_codigo'] . ' ' . $factura['cat_sat_metodo_pago_descripcion'];
        $pdf->SetXY(43.7, 168.3);
        $pdf->MultiCell(
            71.6,
            3,
            mb_convert_encoding($metodo, 'ISO-8859-1', 'UTF-8'),
            0,
            'L'
        );
    }


    private function montos_ivitec(string $tabla, array $factura, Fpdi $pdf): void
    {
        $fmt = new NumberFormatter('es_MX', NumberFormatter::CURRENCY);
        $pdf->SetFont('Arial', '', 8);
        $pdf->SetTextColor(0, 0, 0);

       
        $x = 159.45;
        $w = 40.90;

        $subtotal = $fmt->formatCurrency(round($factura[$tabla . '_sub_total'], 2), 'MXN');
        $pdf->SetXY($x, 149.0);
        $pdf->MultiCell($w, 3, $subtotal, 0, 'R');

        $descuento = $fmt->formatCurrency(round($factura[$tabla . '_descuento'], 2), 'MXN');
        $pdf->SetXY($x, 154.0);
        $pdf->MultiCell($w, 3, $descuento, 0, 'R');

        $traslados = $fmt->formatCurrency(round($factura[$tabla . '_total_traslados'], 2), 'MXN');
        $pdf->SetXY($x, 159.0);
        $pdf->MultiCell($w, 3, $traslados, 0, 'R');

        $retenidos = $fmt->formatCurrency(round($factura[$tabla . '_total_retenciones'], 2), 'MXN');
        $pdf->SetXY($x, 164.0);
        $pdf->MultiCell($w, 3, $retenidos, 0, 'R');

        $pdf->SetFont('Arial', 'B', 9);
        $total_num = round($factura[$tabla . '_total'], 2);
        $total_fmt = $fmt->formatCurrency($total_num, 'MXN');
        $pdf->SetXY(144.64, 169.0);
        $pdf->MultiCell(55.74, 3, $total_fmt, 0, 'R');

        $pdf->SetFont('Arial', '', 7);
        $formatterES = new NumberFormatter('es-ES', NumberFormatter::SPELLOUT);
        $izquierda = (int)floor($total_num);
        $derecha = (int)round(($total_num - floor($total_num)) * 100);
        $letra = strtoupper($formatterES->format($izquierda)) . ' PESOS ';
        $letra .= ($derecha === 0 ? '00' : str_pad((string)$derecha, 2, '0', STR_PAD_LEFT)) . '/100 M.N.';
        $letra = mb_convert_encoding($letra, 'ISO-8859-1', 'UTF-8');

        $pdf->SetXY(15.0, 174.7);
        $pdf->MultiCell(185.4, 2.5, $letra, 0, 'C');
    }


    private function fiscales_ivitec(stdClass $data, Fpdi $pdf): void
    {
        $pdf->SetFont('Arial', '', 7);
        $pdf->SetTextColor(0, 0, 0);

        $folio_fiscal = (string)($data->folio_fiscal ?? '-----');
        $pdf->SetXY(66.0, 193.4);
        $pdf->MultiCell(88.5, 2.7, $folio_fiscal, 0, 'L');

        $rfc_prov = (string)($data->rfc_proveedor ?? '-----');
        $pdf->SetXY(174.6, 193.4);
        $pdf->MultiCell(24.3, 2.7, $rfc_prov, 0, 'L');

        $fecha_timbrado = (string)($data->fecha_timbrado ?? '');
        $pdf->SetXY(74.8, 199.7);
        $pdf->MultiCell(40.9, 2.7, $fecha_timbrado, 0, 'L');

        $no_cert_sat = (string)($data->no_certificado_sat ?? '');
        $pdf->SetXY(146.05, 199.7);
        $pdf->MultiCell(52.9, 2.7, $no_cert_sat, 0, 'L');

    
        $no_cert = (string)($data->no_certificado ?? '-----');
        $pdf->SetXY(71.3, 206.0);
        $pdf->MultiCell(44.4, 2.7, $no_cert, 0, 'L');

    }


  
    private function sellos_ivitec(stdClass $data, Fpdi $pdf): void
    {
       
        $pdf->SetFont('Arial', '', 4.5);
        $pdf->SetTextColor(0, 0, 0);

        $x = 16.0;
        $w = 184.0;
        $h = 1.70;

       
        $pdf->SetXY($x, 229.15);
        $pdf->MultiCell($w, $h, (string)($data->complento ?? ''), 0, 'L');
        $pdf->SetXY($x, 238.0);
        $pdf->MultiCell($w, $h, (string)($data->sello_cfdi ?? ''), 0, 'L');
        $pdf->SetXY($x, 246.8);
        $pdf->MultiCell($w, $h, (string)($data->sello_sat ?? ''), 0, 'L');
    }


    private function cfg_partidas_ivitec(): array
    {
        return [
           
            'y_inicio'       => 115.4,
            'row_h'          => 6,
            'max_por_pagina' => 4,
            'columnas'       => [
                ['key' => '_cantidad',       'x' => 11.3,  'w' => 12.3, 'align' => 'C', 'format' => 'text'],
                ['key' => '_descripcion',    'x' => 87.15, 'w' => 67.7, 'align' => 'L', 'format' => 'text'],
                ['key' => '_valor_unitario', 'x' => 154.9, 'w' => 23.2, 'align' => 'R', 'format' => 'currency'],
                ['key' => '_sub_total',      'x' => 178.2, 'w' => 26.4, 'align' => 'R', 'format' => 'currency'],
            ],
        ];
    }

        private function render_documento_ivitec(
        string $tabla,
        string $tabla_partida,
        array $factura,
        Fpdi $pdf,
        NumberFormatter $fmt,
        stdClass $data,
        array $relacionadas,
        string $ruta_logo,
        string $ruta_qr
    ): void {
        $cfg = $this->cfg_partidas_ivitec();

        $maxPorPagina = max(
            1,
            (int)($cfg['max_por_pagina'] ?? 4)
        );

        $partidas = array_values(
            $factura['partidas'] ?? []
        );

        $paginas = array_chunk(
            $partidas,
            $maxPorPagina
        );

      
        if (count($paginas) === 0) {
            $paginas = [[]];
        }

        $ultimaPagina = count($paginas) - 1;

        foreach ($paginas as $pagina => $partidasPagina) {

            $esUltima = ($pagina === $ultimaPagina);

            if ($esUltima) {

                
                $this->base_pdf_ivitec(
                    tabla: $tabla,
                    data: $data,
                    factura: $factura,
                    pdf: $pdf,
                    relacionadas: $relacionadas,
                    ruta_logo: $ruta_logo,
                    ruta_qr: $ruta_qr
                );

            } else {

               
                $this->base_pdf_ivitec_continuacion(
                    tabla: $tabla,
                    data: $data,
                    factura: $factura,
                    pdf: $pdf
                );
            }

            $this->render_partidas_ivitec_pagina(
                partidas: $partidasPagina,
                tabla_partida: $tabla_partida,
                pdf: $pdf,
                fmt: $fmt,
                cfg: $cfg
            );
        }
    }


   
    private function base_pdf_ivitec_continuacion(
        string $tabla,
        stdClass $data,
        array $factura,
        Fpdi $pdf
    ): void {

        $init = $this->init($pdf);

        if (errores::$error) {
            return;
        }

        $pdf->SetAutoPageBreak(false);

        $this->header_ivitec(
            tabla: $tabla,
            data: $data,
            factura: $factura,
            pdf: $pdf
        );

        $this->receptor_ivitec(
            factura: $factura,
            pdf: $pdf
        );

        $this->comprobante_ivitec(
            tabla: $tabla,
            data: $data,
            factura: $factura,
            pdf: $pdf
        );

      
        $inicioMascara = 142.0;

        $pdf->SetFillColor(
            255,
            255,
            255
        );

        $pdf->Rect(
            0,
            $inicioMascara,
            $pdf->GetPageWidth(),
            $pdf->GetPageHeight() - $inicioMascara,
            'F'
        );
    }


   
    private function render_partidas_ivitec_pagina(
        array $partidas,
        string $tabla_partida,
        Fpdi $pdf,
        NumberFormatter $fmt,
        array $cfg
    ): void {

        $border = 0;
        $lineH = 3.0;

        $y = (float)$cfg['y_inicio'];

        foreach ($partidas as $partida) {

            $pdf->SetFont(
                'Arial',
                '',
                8
            );

            $pdf->SetTextColor(
                0,
                0,
                0
            );

            foreach ($cfg['columnas'] as $col) {

                $key =
                    $tabla_partida .
                    $col['key'];

                $val =
                    $partida[$key] ?? '';

                if ($col['format'] === 'currency') {

                    $val = $fmt->formatCurrency(
                        round(
                            (float)$val,
                            2
                        ),
                        'MXN'
                    );

                } else {

                    $val = mb_convert_encoding(
                        (string)$val,
                        'ISO-8859-1',
                        'UTF-8'
                    );
                }

                $pdf->SetXY(
                    (float)$col['x'],
                    $y
                );

                $pdf->MultiCell(
                    (float)$col['w'],
                    $lineH,
                    $val,
                    $border,
                    (string)$col['align']
                );
            }

            $y += (float)$cfg['row_h'];
        }
    }
}
